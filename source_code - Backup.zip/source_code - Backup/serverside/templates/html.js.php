<?php
if (defined("CLIENT") === FALSE) {
	/**
	* Ghetto way to prevent direct access to "include" files.
	*/
	http_response_code(404);
	die();
}
?>
<script src="static/js/vendor/jquery-2.2.4.min.js"></script>
<script src="static/js/vendor/popper.js"></script>
<script src="static/js/vendor/bootstrap.min.js"></script>
<script src="static/js/vendor/jquery.ajaxchimp.min.js"></script>
<script src="static/js/vendor/jquery.nice-select.min.js"></script>
<script src="static/js/vendor/jquery.sticky.min.js"></script>
<script src="static/js/vendor/nouislider.min.js"></script>
<script src="static/js/vendor/jquery.magnific-popup.min.js"></script>
<script src="static/js/vendor/owl.carousel.min.js"></script>
<script src="static/js/vendor/theme.js"></script>
<script src="static/js/ict1004.js"></script>