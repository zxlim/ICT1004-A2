<?php
##############################
# dbpasswd.php
# Database connection parameters and configuration for MySQLi.
#
# [WARNING] PRIVATE FILE: Contains sensitive credentials.
##############################

if (defined("CLIENT") === FALSE) {
	/**
	* Ghetto way to prevent direct access to "include" files.
	*/
	http_response_code(404);
	die();
}

define("DB_SERVER", "161.117.122.252");
define("DB_NAME", "group8");
define("DB_USER", "group08");
define("DB_PASS", "MveHbNGmgfjlWTD1");