# serverside/private/

Files and folders located in this directory (Except for this "README.md") are classified as "PRIVATE" and <strong>will not</strong> be pushed to the Git repository for security reasons.
<br />
Content that should be located in this folder are to be obtained from an external secure-channel.